#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "dispatcher.h"
#include "shell_builtins.h"
#include "parser.h"

static int mainPipeling(struct command *pipeline, int inPipe[], bool usePipe)
{
	int outPipe[2];
	int pid;

	if (pipeline->output_type == COMMAND_OUTPUT_PIPE) { //Start pipeing
		if (pipe(outPipe) == -1) {
			perror("piping faild\n");
			return 1;
		}
	}

	pid = fork();
	if (pid == 0) {
		if (pipeline->input_filename !=
		    NULL) { //Checking for file input
			FILE *fin = fopen(pipeline->input_filename, "r");
			if (!fin) {
				perror("file input failed\n");
				exit(1);
			}
			if (dup2(fileno(fin), 0) == -1) {
				perror("dup failed\n");
				exit(1);
			}
		}

		if (usePipe) { //Normal command input/ retrieve input from previous pipe
			if (dup2(inPipe[0], STDIN_FILENO) == -1) {
				perror("dup failed\n");
				exit(1);
			}
			close(inPipe[0]);
			close(inPipe[1]);
		}

		if (pipeline->output_type ==
		    COMMAND_OUTPUT_FILE_TRUNCATE) { //Overwrite the file
			FILE *fout = fopen(pipeline->output_filename, "w");
			if (fout == NULL) {
				perror("file output failed\n");
				exit(1);
			}
			if (dup2(fileno(fout), STDOUT_FILENO) == -1) {
				perror("dup failed\n");
				exit(1);
			}
		}

		if (pipeline->output_type ==
		    COMMAND_OUTPUT_FILE_APPEND) { //Append the file
			FILE *fout = fopen(pipeline->output_filename, "a");
			if (fout == NULL) {
				perror("file output failed\n");
				exit(1);
			}
			if (dup2(fileno(fout), STDOUT_FILENO) == -1) {
				perror("dup failed\n");
				exit(1);
			}
		}

		if (pipeline->output_type ==
		    COMMAND_OUTPUT_PIPE) { //base case/command output to terminal
			if (dup2(outPipe[1], STDOUT_FILENO) == -1) {
				perror("dup failed\n");
				exit(1);
			}
			close(outPipe[0]);
			close(outPipe[1]);
		}

		//Run current command and kill all hooligans
		if (execvp(pipeline->argv[0], pipeline->argv) == -1) {
			perror("Error Occurred\n");
			exit(1);
		}
	}
	//wrap up pipes
	if (usePipe) {
		close(inPipe[0]);
		close(inPipe[1]);
	}

	int wstatus; //Wait for child process and get status
	waitpid(pid, &wstatus, 0);

	//Run next command/start the recursive loop
	if (pipeline->output_type == COMMAND_OUTPUT_PIPE) {
		return (mainPipeling(pipeline->pipe_to, outPipe, true));
	}

	if (WIFEXITED(wstatus) == 0 || WEXITSTATUS(wstatus) != 0) {
		perror("External command failed\n");
		return wstatus;
	}

	return 0;
}

/**
 * dispatch_external_command() - run a pipeline of commands
 *
 * @pipeline:   A "struct command" pointer representing one or more
 *              commands chained together in a pipeline.  See the
 *              documentation in parser.h for the layout of this data
 *              structure.  It is also recommended that you use the
 *              "parseview" demo program included in this project to
 *              observe the layout of this structure for a variety of
 *              inputs.
 *
 * Note: this function should not return until all commands in the
 * pipeline have completed their execution.
 *
 * Return: The return status of the last command executed in the
 * pipeline.
 */
static int dispatch_external_command(struct command *pipeline)
{
	/*
	 * Note: this is where you'll start implementing the project.
	 *
	 * It's the only function with a "TODO".  However, if you try
	 * and squeeze your entire external command logic into a
	 * single routine with no helper functions, you'll quickly
	 * find your code becomes sloppy and unmaintainable.
	 *
	 * It's up to *you* to structure your software cleanly.  Write
	 * plenty of helper functions, and even start making yourself
	 * new files if you need.
	 *
	 * For D1: you only need to support running a single command
	 * (not a chain of commands in a pipeline), with no input or
	 * output files (output to stdout only).  In other words, you
	 * may live with the assumption that the "input_file" field in
	 * the pipeline struct you are given is NULL, and that
	 * "output_type" will always be COMMAND_OUTPUT_STDOUT.
	 *hhj
	 * For D2: you'll extend this function to support input and
	 * output files, as well as pipeline functionality.
	 *
	 * Good luck!
	 */

	return mainPipeling(pipeline, NULL, false);
}

/**
 * dispatch_parsed_command() - run a command after it has been parsed
 *
 * @cmd:                The parsed command.
 * @last_rv:            The return code of the previously executed
 *                      command.
 * @shell_should_exit:  Output parameter which is set to true when the
 *                      shell is intended to exit.
 *
 * Return: the return status of the command.
 */
static int dispatch_parsed_command(struct command *cmd, int last_rv,
				   bool *shell_should_exit)
{
	/* First, try to see if it's a builtin. */
	for (size_t i = 0; builtin_commands[i].name; i++) {
		if (!strcmp(builtin_commands[i].name, cmd->argv[0])) {
			/* We found a match!  Run it. */
			return builtin_commands[i].handler(
				(const char *const *)cmd->argv, last_rv,
				shell_should_exit);
		}
	}

	/* Otherwise, it's an external command. */
	return dispatch_external_command(cmd);
}

int shell_command_dispatcher(const char *input, int last_rv,
			     bool *shell_should_exit)
{
	int rv;
	struct command *parse_result;
	enum parse_error parse_error = parse_input(input, &parse_result);

	if (parse_error) {
		fprintf(stderr, "Input parse error: %s\n",
			parse_error_str[parse_error]);
		return -1;
	}

	if (!parse_result)
		return last_rv;

	rv = dispatch_parsed_command(parse_result, last_rv, shell_should_exit);
	free_parse_result(parse_result);
	return rv;
}
